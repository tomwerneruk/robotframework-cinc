=======
History
=======

0.1.4 (2023-01-05)
------------------

* Packaging fixes.

0.1.0 (2022-11-29)
------------------

* First release on PyPI.
