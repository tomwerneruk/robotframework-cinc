=====
Usage
=====

To use cinc Robot Framework Library in a project::

    import robotframework_cinc
