CINCLibrary package
===================

Module contents
---------------

.. automodule:: CINCLibrary
    :members:
    :undoc-members:
    :show-inheritance:
